import scrapy

# initialising the urls so that we can get the urls in our database
urls = ['https://dmoz-odp.org/Sports/Events/',
        'https://dmoz-odp.org/Sports/Hockey/Ice_Hockey/Tournaments/',
        'http://www.bignickelhockey.com/',
        'http: // www.hockeytourney.com /',
        'http: // www.caaahc.com /',
        'http://www.allancup.ca/',
        'http://www.oakscenterice.com/',
        'http://www.bigbeartournaments.com/'
        'http://www.hsviceplex.org/',
        'http://whistlerallstarhockey.ca/?nr=0'

        ]


class QuoteSpider(scrapy.Spider):
    # while running in terminal please use : scrapy crawl web
    name = 'web'
    start_urls = ['https://dmoz-odp.org/Sports/Events/',
                  'https://dmoz-odp.org/Sports/Hockey/Ice_Hockey/Tournaments/',
                  'http://www.bignickelhockey.com/',
                  'http: // www.hockeytourney.com /',
                  'http: // www.caaahc.com /',
                  'http://www.allancup.ca/',
                  'http://www.oakscenterice.com/',
                  'http://www.bigbeartournaments.com/',
                  'http://whistlerallstarhockey.ca/?nr=0'
                  'http://www.hsviceplex.org/'

                  ]

    def parse(self, response):
        all_title = response.css('title::text').extract()

        yield {'------Title-----': all_title, '------urls---': urls}
